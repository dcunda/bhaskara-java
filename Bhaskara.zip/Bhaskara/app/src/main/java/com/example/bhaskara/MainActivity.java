package com.example.bhaskara;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btnSoma;
    TextView txtResultado;
    EditText valora, valorb,valorc;
    Integer num1, num2, num3, soma;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSoma = findViewById(R.id.btnSoma);
        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText valora = findViewById(R.id.valora);
                EditText valorb = findViewById(R.id.valorb);
                EditText valorc = findViewById(R.id.valorc);

                Double num1 = Double.parseDouble(valora.getText().toString());
                Double num2 = Double.parseDouble(valorb.getText().toString());
                Double num3 = Double.parseDouble(valorc.getText().toString());

                Double soma = (num2*num2) - (4*num1*num3);
                Double x1 = (-num2+Math.sqrt(soma))/2*num1;
                Double x2 = (-num2-Math.sqrt(soma))/2*num1;

                TextView txtResultado = findViewById(R.id.txtResultado);
                txtResultado.setText(Double.toString(soma));

            }
        });


    }


}

